"""
transfer_function.py
====================
CNT Humidity Sensor — Transfer Function Analysis & Bode Plot

Calculates the theoretical transfer function H(jω) = Vo/Vin for the
RC-modelled CNT humidity sensor and plots Amplitude + Phase (Bode plot).
Results match LTSpice simulation values from the project documentation.

RC Model: R1=R2=Rf=20kΩ, C1=47nF, C2=470pF, Vin=5V AC
Frequency range: 1 Hz – 1 MHz

Project: Sensor Matrix Simulation — TU Chemnitz, 2017
Author:  Kamal Kadakara
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# -------------------------------------------------------------------------
# Circuit parameters — Humidity Sensor RC Model
# -------------------------------------------------------------------------
R1  = 20e3      # 20 kΩ
R2  = 20e3      # 20 kΩ
Rf  = 20e3      # 20 kΩ (feedback)
Rl  = 20e3      # 20 kΩ (load)
C1  = 47e-9     # 47 nF (varies with humidity)
C2  = 470e-12   # 470 pF
VIN = 5.0       # AC input voltage

# Frequency sweep: 1 Hz to 1 MHz (log scale, 1000 points)
frequencies = np.logspace(0, 6, 1000)
omega       = 2 * np.pi * frequencies


def transfer_function(omega, R1, R2, Rl, C1, C2):
    """
    Calculate complex transfer function H(jω) = Vo/Vin for the
    CNT RC sensor model.

    Numerator:
        Rl * { ω²[(1 + ω²R2²C1²C2² + (C1+C2)²)(Rl+R1) + R2C2²]
               + jω[ω²R2²C1C2² + C1+C2] }

    Denominator:
        [1 - ω²R2C1C2(Rl+R1)]² + [ω(Rl(C1+C2) + C2(R1+R2) + R1C1)]²
    """
    w = omega

    # Numerator — real part coefficient
    num_real = (w**2) * (
        (1 + (w**2) * (R2**2) * (C1**2) * (C2**2) + (C1 + C2)**2)
        * (Rl + R1) + R2 * (C2**2)
    )

    # Numerator — imaginary part coefficient
    num_imag = w * ((w**2) * (R2**2) * C1 * (C2**2) + C1 + C2)

    numerator = Rl * (num_real + 1j * num_imag)

    # Denominator
    den_real = (1 - (w**2) * R2 * C1 * C2 * (Rl + R1))**2
    den_imag = (w * (Rl * (C1 + C2) + C2 * (R1 + R2) + R1 * C1))**2
    denominator = den_real + den_imag

    return numerator / denominator


# Calculate transfer function across frequency range
H = transfer_function(omega, R1, R2, Rl, C1, C2)

amplitude_linear = np.abs(H)
amplitude_db     = 20 * np.log10(amplitude_linear)
phase_deg        = np.angle(H, deg=True)

# -------------------------------------------------------------------------
# Find -3dB cutoff frequency
# -------------------------------------------------------------------------
peak_db      = np.max(amplitude_db)
threshold_db = peak_db - 3.0
crossings    = np.where(np.diff(np.sign(amplitude_db - threshold_db)))[0]
fc           = frequencies[crossings[0]] if len(crossings) > 0 else None

# -------------------------------------------------------------------------
# Theoretical values at 500 Hz (from project report)
# -------------------------------------------------------------------------
idx_500hz  = np.argmin(np.abs(frequencies - 500))
amp_500hz  = amplitude_linear[idx_500hz]
phase_500hz = phase_deg[idx_500hz]

print("=" * 55)
print("  CNT Humidity Sensor — Transfer Function Analysis")
print("  Author: Kamal Kadakara | TU Chemnitz 2017")
print("=" * 55)
print(f"\nRC Parameters:")
print(f"  R1 = R2 = Rf = {R1/1e3:.0f} kΩ")
print(f"  C1 = {C1*1e9:.0f} nF  |  C2 = {C2*1e12:.0f} pF")
print(f"\nAt F = 500 Hz:")
print(f"  Amplitude (linear) = {amp_500hz:.4f}")
print(f"  Amplitude (dB)     = {20*np.log10(amp_500hz):.3f} dB")
print(f"  Phase              = {phase_500hz:.3f}°")
print(f"\n  [Report theoretical] Amplitude = 0.9387, Phase = 18.32°")
print(f"  [Hardware measured ] Amplitude = 0.885,  Phase = 13.79°")
if fc:
    print(f"\n-3dB cutoff frequency Fc = {fc:.1f} Hz")
print("=" * 55)

# -------------------------------------------------------------------------
# Bode Plot — Amplitude and Phase
# -------------------------------------------------------------------------
fig = plt.figure(figsize=(12, 8))
fig.suptitle(
    "CNT Humidity Sensor — Bode Plot (RC Model)\n"
    "R1=R2=Rf=20kΩ, C1=47nF, C2=470pF | Kamal Kadakara | TU Chemnitz 2017",
    fontsize=12, fontweight='bold'
)

gs  = gridspec.GridSpec(2, 1, hspace=0.4)
ax1 = fig.add_subplot(gs[0])
ax2 = fig.add_subplot(gs[1])

# Amplitude plot
ax1.semilogx(frequencies, amplitude_db, 'b-', linewidth=2, label='H(jω) Amplitude')
ax1.axhline(y=peak_db - 3, color='r', linestyle='--', alpha=0.7, label='-3dB line')
if fc:
    ax1.axvline(x=fc, color='g', linestyle='--', alpha=0.7, label=f'Fc = {fc:.1f} Hz')
ax1.axvline(x=500, color='orange', linestyle=':', alpha=0.8, label='500 Hz (test point)')
ax1.set_ylabel('Amplitude (dB)')
ax1.set_title('Amplitude Response')
ax1.legend(fontsize=9)
ax1.grid(True, which='both', alpha=0.3)
ax1.set_xlim([1, 1e6])

# Phase plot
ax2.semilogx(frequencies, phase_deg, 'r-', linewidth=2, label='H(jω) Phase')
ax2.axvline(x=500, color='orange', linestyle=':', alpha=0.8, label='500 Hz (test point)')
ax2.set_xlabel('Frequency (Hz)')
ax2.set_ylabel('Phase (degrees)')
ax2.set_title('Phase Response')
ax2.legend(fontsize=9)
ax2.grid(True, which='both', alpha=0.3)
ax2.set_xlim([1, 1e6])

plt.savefig('humidity_sensor_bode_plot.png', dpi=150, bbox_inches='tight')
plt.show()
print("\nBode plot saved as: humidity_sensor_bode_plot.png")


# -------------------------------------------------------------------------
# Humidity sensitivity analysis — sweep C1 (capacitance varies with RH)
# -------------------------------------------------------------------------
print("\nHumidity Sensitivity Analysis (C1 variation):")
print(f"{'RH%':>6} | {'C1 (nF)':>10} | {'Amp @ 500Hz':>12} | {'Phase @ 500Hz':>14}")
print("-" * 52)

rh_values = [0, 20, 40, 60, 80, 100]

for rh in rh_values:
    # C1 increases with humidity (CNT property) — 47nF at 0%, ~94nF at 100%
    c1_rh = C1 * (1 + rh / 100.0)
    H_rh  = transfer_function(np.array([2 * np.pi * 500]),
                               R1, R2, Rl, c1_rh, C2)
    amp   = np.abs(H_rh[0])
    phase = np.angle(H_rh[0], deg=True)
    print(f"{rh:>6}% | {c1_rh*1e9:>10.1f} | {amp:>12.4f} | {phase:>12.3f}°")
