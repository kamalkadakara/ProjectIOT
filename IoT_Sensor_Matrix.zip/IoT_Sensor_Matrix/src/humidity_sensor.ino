/**
 * @file    humidity_sensor.ino
 * @brief   CNT Humidity Sensor — Arduino Data Acquisition
 *
 * Reads voltage output from the RC-modelled CNT humidity sensor circuit,
 * calculates amplitude ratio and estimates relative humidity based on
 * capacitance-shift in the RC network.
 *
 * RC Model: R1=R2=Rf=20kΩ, C1=47nF (varies with humidity), C2=470pF
 * Input: 5V AC at 500 Hz (generated via PWM)
 * Output: Amplitude and Phase shift → mapped to % Relative Humidity
 *
 * Hardware:
 *   - Arduino Uno (ATmega328P)
 *   - Analog pin A0 → Vin (reference)
 *   - Analog pin A1 → Vout (sensor output)
 *   - Serial Monitor: 9600 baud
 *
 * Project: Sensor Matrix Simulation — TU Chemnitz, 2017
 * Author:  Kamal Kadakara
 */

/* -------------------------------------------------------------------------
 * Configuration
 * ---------------------------------------------------------------------- */
const int    PIN_VIN        = A0;   /* Reference input voltage              */
const int    PIN_VOUT       = A1;   /* Sensor output voltage                */
const int    PIN_AC_OUT     = 9;    /* PWM pin for AC signal generation     */
const float  VREF           = 5.0f; /* Arduino reference voltage            */
const int    ADC_RESOLUTION = 1024; /* 10-bit ADC                           */
const float  AC_FREQ_HZ     = 500.0f;

/* Calibration — derived from LTSpice simulation and hardware measurements  */
/* At 0% RH: C1 = 47nF  → Amplitude ratio ≈ 0.885                         */
/* At 100% RH: C1 = 94nF → Amplitude ratio ≈ 0.72 (capacitance doubles)   */
const float  AMPLITUDE_DRY  = 0.885f;   /* 0% RH reference                  */
const float  AMPLITUDE_WET  = 0.720f;   /* 100% RH reference                */

/* -------------------------------------------------------------------------
 * Global variables
 * ---------------------------------------------------------------------- */
float gAmplitudeRatio  = 0.0f;
float gRelativeHumidity = 0.0f;
int   gSampleCount     = 0;

/* -------------------------------------------------------------------------
 * Setup
 * ---------------------------------------------------------------------- */
void setup()
{
    Serial.begin(9600);
    pinMode(PIN_AC_OUT, OUTPUT);
    pinMode(PIN_VIN,    INPUT);
    pinMode(PIN_VOUT,   INPUT);

    Serial.println("===========================================");
    Serial.println("  CNT Humidity Sensor — Kamal Kadakara    ");
    Serial.println("  TU Chemnitz Project Lab — 2017          ");
    Serial.println("===========================================");
    Serial.println("Sample | Vin(V) | Vout(V) | Ratio | RH%  ");
    Serial.println("-------------------------------------------");

    /* Generate 500 Hz AC signal via Timer1 PWM */
    setupTimer1_500Hz();
}

/* -------------------------------------------------------------------------
 * Main loop — sample every 100ms, print to serial
 * ---------------------------------------------------------------------- */
void loop()
{
    /* Read peak Vin and Vout over one AC cycle (2ms at 500Hz) */
    float vinPeak  = measurePeakVoltage(PIN_VIN,  20);
    float voutPeak = measurePeakVoltage(PIN_VOUT, 20);

    /* Calculate amplitude ratio */
    if (vinPeak > 0.01f)
    {
        gAmplitudeRatio = voutPeak / vinPeak;
    }

    /* Map amplitude ratio to relative humidity (linear approximation) */
    gRelativeHumidity = mapAmplitudeToHumidity(gAmplitudeRatio);
    gSampleCount++;

    /* Print to serial monitor */
    Serial.print(gSampleCount);
    Serial.print("      | ");
    Serial.print(vinPeak,  3);
    Serial.print("   | ");
    Serial.print(voutPeak, 3);
    Serial.print("    | ");
    Serial.print(gAmplitudeRatio, 3);
    Serial.print("  | ");
    Serial.print(gRelativeHumidity, 1);
    Serial.println("%");

    delay(100);
}

/* -------------------------------------------------------------------------
 * @brief   Measure peak voltage on an analog pin over N samples
 *
 * @param   pin       Analog pin number
 * @param   samples   Number of ADC samples to take
 * @return  Peak voltage in volts
 * ---------------------------------------------------------------------- */
float measurePeakVoltage(int pin, int samples)
{
    int   peakRaw = 0;
    float voltage = 0.0f;

    for (int i = 0; i < samples; i++)
    {
        int raw = analogRead(pin);
        if (raw > peakRaw) peakRaw = raw;
        delayMicroseconds(100);  /* Sample spread across AC cycle */
    }

    voltage = (float)peakRaw * (VREF / (float)ADC_RESOLUTION);
    return voltage;
}

/* -------------------------------------------------------------------------
 * @brief   Map amplitude ratio to Relative Humidity percentage
 *          Linear model between calibration points:
 *          0% RH → ratio 0.885
 *          100% RH → ratio 0.720
 *
 * @param   ratio  Vout/Vin amplitude ratio
 * @return  Estimated relative humidity (0–100%)
 * ---------------------------------------------------------------------- */
float mapAmplitudeToHumidity(float ratio)
{
    /* Linear interpolation between dry and wet calibration points */
    float rh = ((AMPLITUDE_DRY - ratio) / (AMPLITUDE_DRY - AMPLITUDE_WET)) * 100.0f;

    /* Clamp to valid range */
    if (rh < 0.0f)   rh = 0.0f;
    if (rh > 100.0f) rh = 100.0f;

    return rh;
}

/* -------------------------------------------------------------------------
 * @brief   Configure Timer1 for 500 Hz PWM on pin 9
 *          CTC mode: OCR1A = (F_CPU / (2 * prescaler * freq)) - 1
 *          At 16MHz, prescaler=16: OCR1A = (16M / (2*16*500)) - 1 = 999
 * ---------------------------------------------------------------------- */
void setupTimer1_500Hz()
{
    TCCR1A = 0;
    TCCR1B = 0;
    TCNT1  = 0;

    OCR1A  = 999;                      /* Compare match value for 500 Hz    */
    TCCR1B |= (1 << WGM12);           /* CTC mode                          */
    TCCR1B |= (1 << CS11) | (1 << CS10); /* Prescaler = 64                 */
    TIMSK1 |= (1 << OCIE1A);          /* Enable compare match interrupt     */
}

/* -------------------------------------------------------------------------
 * Timer1 Compare Match ISR — toggle pin 9 to generate AC square wave
 * ---------------------------------------------------------------------- */
ISR(TIMER1_COMPA_vect)
{
    static uint8_t state = 0;
    state ^= 1U;
    digitalWrite(PIN_AC_OUT, state);
}
