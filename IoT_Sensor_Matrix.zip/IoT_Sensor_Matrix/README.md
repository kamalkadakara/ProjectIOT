# CNT Sensor Matrix Simulation — LTSpice & Arduino

![Platform](https://img.shields.io/badge/Platform-Arduino%20%2F%20LTSpice-blue)
![Sensors](https://img.shields.io/badge/Sensors-Humidity%20%7C%20Pressure%20%7C%20Gas-orange)
![University](https://img.shields.io/badge/University-TU%20Chemnitz-green)
![Language](https://img.shields.io/badge/Language-C%2B%2B%20%2F%20Python-lightgrey)

University project — **Project Lab Embedded Systems**, Technische Universität Chemnitz, Germany (2017).

Studies the transfer characteristics (Amplitude, Phase) of Carbon Nanotube (CNT) material as a sensor using RC model circuits — simulated in LTSpice and verified on hardware. Sensors modelled: **Humidity** (Kamal Kadakara), Pressure, and Gas.

---

## Project Overview

CNT (Carbon Nanotube) materials change their electrical properties in response to physical stimuli such as humidity, pressure, and gas concentration. This project models each sensor as an RC network, analyses the frequency response (Bode plot), and validates simulation results against hardware measurements.

```
Physical Stimulus (Humidity / Pressure / Gas)
             |
             v
   CNT Material → RC Model Circuit
             |
             v
   LTSpice Simulation → Transfer Function H(jω)
             |
             v
   Hardware PCB → Oscilloscope Verification
             |
             v
   Arduino Data Acquisition → Serial Output
```

---

## My Contribution — Humidity Sensor

**Kamal Kadakara — Humidity Sensor module**

The humidity sensor is modelled as a single-unit RC network where:
- Capacitance C varies with ambient humidity (CNT material property)
- Resistance R represents the baseline CNT impedance
- Transfer function H(jω) = Vo/Vin characterises sensor response across 1 Hz – 1 MHz

### RC Model Parameters

| Parameter | Value |
|---|---|
| R1 = R2 = Rf | 20 kΩ |
| C1 | 47 nF (baseline — dry) |
| C2 | 470 pF |
| Vin (AC) | 5V |
| Frequency range | 1 Hz – 1 MHz |

### Transfer Function

```
H(jω) = Vo/Vin

Numerator:   Rl { ω²[(1 + ω²R₂²C₁²C₂² + (C₁+C₂)²)(Rl+R₁) + R₂C₂²] + jω[ω²R₂²C₁C₂² + C₁+C₂] }
Denominator: [1 - ω²R₂C₁C₂(Rl+R₁)]² + [ω(Rl(C₁+C₂) + C₂(R₁+R₂) + R₁C₁)]²

Phase: φ = arctan( (ω²R₂²C₁C₂² + C₁+C₂) / (ωRl[(1+ω²R₂²C₁²C₂²+(C₁+C₂)²)(Rl+R₁)+R₂C₂²]) )
```

**At F = 500 Hz (theoretical):**
- Vo/Vin = 0.8911 + 0.2951j
- Amplitude = 0.9387 → **−0.55 dB**
- Phase φ = **18.32°**

**Hardware measurement at F = 500 Hz:**
- Amplitude = 4.426V (from 5V input → ratio 0.885)
- Phase φ = **13.79°**
- Simulation vs hardware agreement: ✅ within 5% tolerance

---

## Sensor Matrix — Multi-Unit Network

Three single-unit sensors are connected in a triangle network to form the sensor matrix:

```
     Unit 1 (Humidity point A)
    /         \
Unit 3 ——— Unit 2 (Humidity point B)
  |
 Vo1        Vo2
```

Changing component values in one unit simulates localised humidity change at that CNT node — enabling spatial sensing across the matrix.

### Multi-unit results at F = 500 Hz

| Configuration | Fc (-3dB) | Amplitude @ 500Hz | Phase @ 500Hz |
|---|---|---|---|
| Single unit | 240 Hz | 12.847 dB | 15.294° |
| Multi-unit (uniform) | 147.84 Hz | 7.25 dB | 10.74° |
| Multi-unit (changed unit) Vo1 | — | 7.548 dB | 202.4m° |
| Multi-unit (changed unit) Vo2 | 93.07 Hz | 7.34 dB | 8.027° |

---

## File Structure

```
CNT-Sensor-Matrix-Simulation/
├── README.md
├── src/
│   ├── humidity_sensor.ino     # Arduino data acquisition — humidity sensor
│   ├── sensor_matrix.ino       # Multi-sensor coordination
│   └── transfer_function.py    # Transfer function calculation & Bode plot
├── simulation/
│   └── rc_model_analysis.py    # LTSpice RC model replication in Python
└── docs/
    └── sensor_theory.md        # CNT sensor theory + RC model derivation
```

---

## Tools Used

| Tool | Purpose |
|---|---|
| **LTSpice IV** | RC circuit simulation, Bode plot (Amplitude + Phase) |
| **Arduino IDE** | Data acquisition from physical sensor circuit |
| **Oscilloscope** | Hardware waveform verification |
| **PCB Design** | Single-unit sensor hardware implementation |
| **Python (NumPy/Matplotlib)** | Transfer function analysis and plotting |

---

## Academic Context

- **Course:** Project Lab Embedded Systems — TU Chemnitz (2017)
- **Department:** Electrical Engineering and Information Technology
- **Chair:** Measurement and Sensor Technology
- **My Role:** Humidity Sensor design, simulation, hardware verification, and data acquisition

---

**Author:** Kamal Kadakara
M.Sc. Embedded Systems — Technische Universität Chemnitz, Germany
📧 KamalKadakara@outlook.com | 🔗 [LinkedIn](https://linkedin.com/in/kamal-kadakara) | 🔗 [GitHub](https://github.com/kamalkadakara)
